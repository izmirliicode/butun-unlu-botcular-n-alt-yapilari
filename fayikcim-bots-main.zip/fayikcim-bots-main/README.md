# fayikcim-bots


Zamanında bize(Spanker ve Bana) "Noname","Türeme" gibi hitaplarda bulunan "Fayikcimin" professional main botlarına bakalım hadi xd :DDDD

Aether & Shinoa tarafından özenle paylaşıldı :)


-Shinoa
