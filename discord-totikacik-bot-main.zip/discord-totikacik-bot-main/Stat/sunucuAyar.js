const ayarlar = {
  guildID: '', // sunucu idsi
  ownerRole:"", // sunucu sahiplerinin rolü
  teyitsizRolleri:[], // kayıt olmayanlara verieln rol
  jailRolu:"", // cezalılara verilen rol
  enAltYetkiliRolu:[], // ilk yetkili permi
  activity:"Totika ❤ Cofteey", // botun durumu
  status:"online",
  invitelink:"", //davet linki
  symbol:"", // tag
  voicechannel:"" // botun gireceği ses kanalı
};
module.exports = ayarlar;