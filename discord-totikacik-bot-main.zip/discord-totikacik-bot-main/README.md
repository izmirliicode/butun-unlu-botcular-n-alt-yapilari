Totika arkadaşımızın botlarına buradan ulaşabilirsiniz. Güya kendi yazdığı botları alt yapı kullanarak "BEN" yaptım diye göstermesi de ayrı bir olay.
Zamanında Alicem Dante'nin açtığı sunucuda 30 Guard koymuş olduğum ve sunucu bot üstünden patlayınca bana laf olarak gönderme yapan "TOTİKAMA" gelsin :)

- Kullandığı Moderasyon: https://github.com/iOwsla/Wency-Toku-ibidi
- Kullandığı Yetkili XP: https://github.com/thearkxd/discord-advanced-stat-bot
- Kullandığı Stats Botu: https://github.com/yashinu/discord-yashinu-statbot

![image](https://user-images.githubusercontent.com/39532511/117366338-44270700-aec9-11eb-84cb-0dc02ae59cad.png)
![image](https://user-images.githubusercontent.com/39532511/117366349-48532480-aec9-11eb-9ed0-0156a46f598f.png)
