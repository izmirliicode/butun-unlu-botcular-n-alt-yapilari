# yeni tantoony altyapisi
Eskiden ortağım dediğim karaktersiz bir insansı varlığın daha önce paylaştığı altyapımı sizlere sunuyorum
* npm i
* npm i pm2 -g
* pm2 start eco.config.js
