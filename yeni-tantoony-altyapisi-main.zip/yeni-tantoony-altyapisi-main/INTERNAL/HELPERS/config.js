module.exports = {
	mongoDB: "mongodb://localhost/Hub",
	owner: "674565119161794560",
    server: "795403348411940914",
	prefix: '.',
    project: "HUB",
    status: {
        name: "ZİH̨̢̀İ͚̹Ņ͟͝SE͎͔̪L̖ ̅̏̃҉SO̅RU̿͂ͣǸ̅̏ ͋̅͊Y̷̸͟Aͯ̋̈RDIͫ̄͠M̄̃̏ ͑ͪͬE̒̎ͫDİͥ̌͑N",
        type: "LISTENING"
    },
    tag: null
}