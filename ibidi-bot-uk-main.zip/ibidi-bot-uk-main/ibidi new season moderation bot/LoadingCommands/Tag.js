module.exports.operate = async ({client, msg, args,auth, author}, fetch = require('node-fetch'), Schema = require("../Models/Member.js")) => {
client.message(`${auth.Tags.RealTag}`, msg.channel.id, 6500);
  };
    
  module.exports.help = {
    name: "tag",
    alias: []
  };
 

 